import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { TextField, Button } from '@material-ui/core';

const useStyles = makeStyles({
  form: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: '20px',
  },
  input: {
    marginBottom: '10px',
  },
  button: {
    marginTop: '20px',
  },
});

function App() {
  const classes = useStyles();

  return (
    <div className="App">
      <form className={classes.form}>
        <TextField
          label="Username"
          variant="outlined"
          className={classes.input}
        />
        <TextField
          label="Password"
          variant="outlined"
          type="password"
          className={classes.input}
        />
        <Button
          variant="contained"
          color="primary"
          className={classes.button}
        >
          Login
        </Button>
      </form>
    </div>
  );
}

export default App;
